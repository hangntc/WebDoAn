﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace API.Areas.Admin.Controllers
{
    public class UploadImageController : ApiController
    {
        // POST api/<controller>
       
    }
}
